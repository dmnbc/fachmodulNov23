#pragma once
#include "Figur.h"
class Turm :
    public Figur
{
public:
    Turm();
};

