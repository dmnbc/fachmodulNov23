#pragma once

#include <iostream>
#include "Figur.h"
class Feld
{ private:
	char feldFarbe;
	Figur figur;

public:
	Feld();
	char get_feldFarbe() { return feldFarbe;  }
};

