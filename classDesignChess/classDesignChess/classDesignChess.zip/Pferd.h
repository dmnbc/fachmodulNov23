#pragma once
#include "Figur.h"
class Pferd :
    public Figur
{
public:
    Pferd();
};

