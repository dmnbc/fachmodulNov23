#include "Dame.h"

Dame::Dame()
{
	std::cout << __LINE__ << ":" << __FILE__ << "ctor Dame()\n";
}
