#include "Turm.h"

Turm::Turm()
{
	std::cout << __LINE__ << ":" << __FILE__ << "ctor Turm()\n";
}