#pragma once
#include "Figur.h"
class Laeufer :
    public Figur
{
public:
	Laeufer();
};

