#include "Figur.h"

Figur::Figur()
{
	std::cout << __LINE__ << ":" << __FILE__ << "ctor Figur()\n"; 
}


