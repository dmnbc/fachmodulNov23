#pragma once
#include "Figur.h"
class Dame :
    public Figur
{
public:
    Dame();
};

