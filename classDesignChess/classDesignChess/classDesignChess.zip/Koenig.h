#pragma once
#include "Figur.h"
class Koenig :
    public Figur
{
public:
    Koenig();
};

