#pragma once

#include <array>

#include "Feld.h"

using namespace std; 

class Spiel
{
private:
	// das spielfeld hat 64 Felder
	array<array<Feld, 8>, 8> spielfeld;
public:
	Spiel();


};

