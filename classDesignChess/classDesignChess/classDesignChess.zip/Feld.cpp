#include "Feld.h"

Feld::Feld()
{
	std::cout << __LINE__ << ":" << __FILE__ << "ctor Feld()\n";
}
