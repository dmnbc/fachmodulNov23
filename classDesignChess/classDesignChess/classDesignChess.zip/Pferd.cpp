#include "Pferd.h"

Pferd::Pferd()
{
	std::cout << __LINE__ << ":" << __FILE__ << "ctor Pferd()\n";
}