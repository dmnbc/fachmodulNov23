#include "Spiel.h"

Spiel::Spiel()
{
	std::cout << __LINE__ << ":" << __FILE__ << "ctor Spiel()\n";
}