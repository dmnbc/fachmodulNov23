#include "Koenig.h"

Koenig::Koenig()
{
	std::cout << __LINE__ << ":" << __FILE__ << "ctor Koenig()\n";
}
