#pragma once
#include "Figur.h"
class Bauer :
    public Figur
{
public:
    Bauer();
};

