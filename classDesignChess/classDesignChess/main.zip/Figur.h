#pragma once
#include <iostream>
class Figur
{
public:
	Figur();
	
};

