#include "Laeufer.h"

Laeufer::Laeufer()
{
	std::cout << __LINE__ << ":" << __FILE__ << "ctor Laeufer()\n";
}