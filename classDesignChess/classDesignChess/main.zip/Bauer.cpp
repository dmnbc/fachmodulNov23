#include "Bauer.h"

Bauer::Bauer()
{
	std::cout << __LINE__ << ":" << __FILE__ << "ctor Bauer()\n";
}